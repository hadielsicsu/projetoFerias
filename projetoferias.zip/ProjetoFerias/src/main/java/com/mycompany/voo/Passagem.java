/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.voo;

/**
 *
 * @author hadielsicsu
 */
public class Passagem {
    private final Voo voo;
    private final int numeroPassageiros;

    public Passagem(Voo voo, int numeroPassageiros) {
        this.voo = voo;
        this.numeroPassageiros = numeroPassageiros;
    }

    public Voo getVoo() {
        return voo;
    }

    public int getNumeroPassageiros() {
        return numeroPassageiros;
    }
}
