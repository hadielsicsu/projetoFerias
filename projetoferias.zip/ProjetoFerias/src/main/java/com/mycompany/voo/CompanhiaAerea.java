/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.voo;

/**
 *
 * @author hadielsicsu
 */
public class CompanhiaAerea {
    public boolean efetuarReserva(Passagem passagem) {
       
        
        return passagem != null && passagem.getVoo().reservarAssentos(passagem.getNumeroPassageiros());
    }

    public boolean cancelarReserva(Passagem passagem) {
        if (passagem != null) {
            passagem.getVoo().liberarAssentos(passagem.getNumeroPassageiros());
           
            return true;
        }
        return false;
    }

    
}
