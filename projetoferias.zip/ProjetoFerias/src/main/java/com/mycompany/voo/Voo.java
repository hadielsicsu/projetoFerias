/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.voo;

/**
 *
 * @author hadielsicsu
 */
public class Voo {
    private final int capacidadeTotal;
    private int assentosReservados;

    public Voo(int capacidadeTotal) {
        this.capacidadeTotal = capacidadeTotal;
        this.assentosReservados = 0;
    }

    public int getCapacidadeTotal() {
        return capacidadeTotal;
    }

    public int getAssentosReservados() {
        return assentosReservados;
    }

    public boolean reservarAssentos(int quantidade) {
        if (assentosReservados + quantidade <= capacidadeTotal) {
            assentosReservados += quantidade;
            return true;
        } else {
            return false;
        }
    }

    public void liberarAssentos(int quantidade) {
        assentosReservados -= quantidade;
    }
}

