/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package com.mycompany.voo;

import static org.testng.Assert.*;
import org.junit.Test;

/**
 *
 * @author hadielsicsu
 */


public class CompanhiaAereaTest {

    @Test
    public void testeReservaBemSucedida() {
        Voo voo = new Voo(50);
        Passagem passagem = new Passagem(voo, 2);
        CompanhiaAerea companhia = new CompanhiaAerea();

        assertTrue(companhia.efetuarReserva(passagem));
    }

    @Test
    public void testeDisponibilidadeAssentos() {
        Voo voo = new Voo(50);
        Passagem passagem = new Passagem(voo, 55);
        CompanhiaAerea companhia = new CompanhiaAerea();

        assertFalse(companhia.efetuarReserva(passagem));
    }

    @Test
    public void testeCancelamentoReserva() {
        Voo voo = new Voo(50);
        Passagem passagem = new Passagem(voo, 2);
        CompanhiaAerea companhia = new CompanhiaAerea();

        assertTrue(companhia.efetuarReserva(passagem));
        assertTrue(companhia.cancelarReserva(passagem));
    }

    // Implemente os outros testes conforme necessário
}

